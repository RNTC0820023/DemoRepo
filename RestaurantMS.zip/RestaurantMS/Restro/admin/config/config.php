
<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="rposystem";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>