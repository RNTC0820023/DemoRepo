<footer class="py-5">
  <div class="container">
    <div class="row align-items-center justify-content-xl-between">
      <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
        &copy; 2020 - <?php echo date('Y'); ?> - Developed by CP08 G3(2020-2023) 
        </div>
      </div>
      <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
          <li class="nav-item">
            <a href="http://localhost/RestaurantMS/" class="nav-link" target="_blank">Restaurant M.S.</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>